package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class OrangeHRMLoginPage {
    WebDriver driver = null;
    By textbox_username = By.id("txtUsername");
    By textbox_password = By.id("txtPassword");
    By button_login = By.id("btnLogin");
    //constructor to create driver everytime the OrangeHRMLoginPage is called
    public OrangeHRMLoginPage(WebDriver driver){
        //we are using this keyword to keep the driver name the same instead of saying driver = driver1;
        this.driver = driver;
    }

    public void setTextInUsernameBox(String text){
        driver.findElement(textbox_username).sendKeys(text);
    }

    public void setTextInPasswordBox(String text){
        driver.findElement(textbox_password).sendKeys(text);
    }

    public void clickLoginButton(){
        WebDriverWait wait = new WebDriverWait(driver, 10);
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(button_login));
        driver.findElement(button_login).sendKeys(Keys.RETURN);
    }
}

