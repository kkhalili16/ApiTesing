package pages;

import com.BaseClassWebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import com.BaseClass;
import org.openqa.selenium.WebDriver;

public class GoogleSearchPage2 extends BaseClassWebDriver {
    //WebDriver driver = null;
    By textbox_search = By.name("q");
    By button_search = By.name("btnK");
    //constructor to create driver everytime the GoogleSearchPage2 is called
    public GoogleSearchPage2(WebDriver driver){
        //we are using this keyword to keep the driver name the same instead of saying driver = driver1;
        this.driver = driver;
    }

    public void setTextInSearchBox(String text){
        driver.findElement(textbox_search).sendKeys(text);
    }
    public void clickSearchButton(){
        driver.findElement(button_search).sendKeys(Keys.RETURN);
    }
}
