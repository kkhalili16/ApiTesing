package test;

import com.BaseClass;
import com.google.common.base.Verify;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
// calling extent report from TestNG
// calling page object page for google search page
//read the test data excel file

public class AutoITDemoFileUpload extends BaseClass {

    @DataProvider(name = "test1data")
    public Object[][] getData(){
        String excelPath =  projectPath+"/excel/data.xlsx";
        Object data[][] = testData(excelPath, "Sheet2");
        return data;
    }

    @Test(dataProvider = "test1data")
    public void tinyupload(String url, String filePath) throws Exception {
        /* if you want to run it without testng xml file use the code below and remove Base class
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.get("http://www.tinyupload.com");
        */
        SoftAssert softAssert = new SoftAssert();
        test = extent.createTest("Tiny Upload", "Tiny Upload using AutoIT windows desktop automation");
        try {
            logger.info("Navigated to " + url);
            test.pass("Navigated to " + url);
            Thread.sleep(2000);

            //Actions builder = new Actions(driver);
            //builder.moveToElement(driver.findElement(By.xpath("//input[@type='file']"))).click().build().perform();
            //Thread.sleep(2000);
            //**code below works**
            WebElement elem = chrome.findElement(By.xpath("//input[@type='file']"));
            //elem.sendKeys("C:\\Temp\\file1.txt");
            //logger.info("Clicked the choose file button");
            //test.pass("Clicked the choose file button");
            //Runtime.getRuntime().exec(filePath);
            //logger.info("Entered the file path using AutoIT windows desktop automayion");
            //test.pass("Entered the file path [ " + filePath + " ] using AutoIT windows desktop automation");
            Thread.sleep(2000);
            //takeSnapShot(driver, "c:\\Temp\\test.png") ;
            //Assert.assertTrue(false);
            Boolean verifyTitle = chrome.getTitle().equalsIgnoreCase("TinyUpload.com - best file hosting solution, with no limits, totaly free");
            softAssert.assertNull(verifyTitle);
            softAssert.assertNotNull(verifyTitle);

            chrome.close();
            chrome.quit();
            //driver.findElement(By.xpath("//input[@type='filex']"));
        }catch (Exception exp){
            exp.getMessage();
            chrome.close();
            chrome.quit();
        }
    }
}
