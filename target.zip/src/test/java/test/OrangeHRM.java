package test;

import com.BaseClass;
import com.BaseClassWebDriver;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.OrangeHRMLoginPage;
import utils.Utility;

// calling extent report from TestNG
// calling page object page for google search page
//read the test data excel file
public class OrangeHRM extends BaseClassWebDriver {
    //setting up the test data file which will read the values from the Base class method testData()
    @DataProvider(name = "test1data")
    public Object[][] getData() {
        String excelPath = projectPath + "/excel/data.xlsx";
        Object data[][] = testData(excelPath, "Sheet1");
        return data;
    }
    // the test data that was retrived in the getData method needs to be declared as variables in the test.
    @Test(dataProvider = "test1data")
    public void orangeHRMLogin(String username, String password, String search, String googleURL) throws Exception {
        test = extent.createTest("OrangeHRM Login", "Login to OrangeHRM web app");
        try {
            //get the value from the excel sheet1 row 1 and column 2
            //String test1 = excel.getCellDataString(1,2);
            // Test Case name and description
            test.log(Status.INFO, "Starting Test Case");
            //test.addScreenCaptureFromPath("screenshot.png");
            /*
            - Enter user name
            - Enter password
            - Click the LOGIN button
            */
            OrangeHRMLoginPage loginPageObj = new OrangeHRMLoginPage(driver);
            loginPageObj.setTextInUsernameBox(username);
            logger.info("Entered text " + username + " in username textbox");
            test.pass("Entered text " + username + " in username textbox");

            loginPageObj.setTextInPasswordBox(password);
            logger.info("Entered text " + password + " in password textbox");
            test.pass("Entered text " + password + " in password textbox");

            loginPageObj.clickLoginButton();
            logger.info("Pressed login button");
            test.pass("Pressed login button");
            Thread.sleep(3000);
            loginPageObj.clickLoginButton();
        } catch (Exception exp) {
            test.fail("somthing went wrong =>" + exp.getMessage());
            test.fail(MediaEntityBuilder.createScreenCaptureFromPath("img.png").build());
            test.log(Status.FAIL, "test failed");
            driver.close();
        }
    }
}

/*
    @Test(priority = 0, retryAnalyzer = MyRetry.class, groups = {"sanity"})
    public void test3(){
        System.out.println("I am inside test 3");
        int i = 1/0;
    }

    @Test(priority = 0, groups = {"break"})
    public void test4(){
        System.out.println("I am inside test 4");
        int i = 1/0;
    }
*/

    /*
    catch (Exception exp){
        // reference image saved to disk
        test.fail("details one",
                MediaEntityBuilder.createScreenCaptureFromPath("screenshot.jpg").build());
        test.fail("something went wrong =>"+ exp.getMessage());
    }

   /* @Test
    public void test11(){
        System.out.println("I am inside Test 1");
    }
    @Test
    public void test12(){
        System.out.println("I am inside Test 2");
        Assert.assertTrue(false);
    }
    @Test
    public void test13(){
        System.out.println("I am inside Test 3");
        throw new SkipException("This test is skipped");
    }*/

