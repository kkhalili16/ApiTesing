package test;

import com.BaseClass;
import com.BaseClassWebDriver;
import com.aventstack.extentreports.Status;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.GoogleSearchPage2;
import test.old.test;

public class GoogleSearch extends BaseClassWebDriver {

    //setting up the test data file which will read the values from the Base class method testData()
    @DataProvider(name = "test1data")
    public Object[][] getData(){
        String excelPath =  projectPath+"/excel/data.xlsx";
        Object data[][] = testData(excelPath, "Sheet1");
        return data;
    }
    @Test(dataProvider = "test1data")
    public void googleSearch(String username, String password, String search, String googleURL) {
        //get the value from the excel sheet1 row 1 and column 2
        //String test1 = excel.getCellDataString(1,2);
        System.out.println("This is the search text1 xyz--------: " + search);
        // Test Case name and description
        test = extent.createTest("Google Search", "Search for a word in google search");
        try {
            driver.get(googleURL);
            Thread.sleep(2000);
            test.log(Status.INFO, "Starting Test Case");
            logger.info("Navigated to " + googleURL);
            test.pass("Navigated to " + googleURL);

            GoogleSearchPage2 googlePageObj = new GoogleSearchPage2(driver);
            googlePageObj.setTextInSearchBox(search);
            System.out.println("Search word is " + search);
            logger.info("Entered text " + search + " in search textbox");
            test.pass("Entered text " + search + " in search textbox");

            googlePageObj.clickSearchButton();
            logger.info("Pressed login button");
            test.pass("Pressed login button");
            driver.close();
        }catch (Exception exp){
            test.log(Status.FAIL, exp.getCause().getMessage());
        }
    }
}
