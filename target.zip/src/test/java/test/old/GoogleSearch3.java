package test.old;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import pages.GoogleSearchPage2;

// calling page object page for google search page

public class GoogleSearch3 {
    private static RemoteWebDriver driver = null;

    public static void main(String[] args) {
        googleSearch();
    }

    public static void googleSearch(){
        //WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        //goto google.com
        driver.get("https://www.google.com");

        GoogleSearchPage2 searchPageObj = new GoogleSearchPage2(driver);
        searchPageObj.setTextInSearchBox("Automation step by step");
        searchPageObj.clickSearchButton();

        //close browser
        driver.close();
        driver.quit();
        System.out.println("Test Pass!!!");
    }
}
