package test.old;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class log4jdemo {

    private static Logger Logger = LogManager.getLogger(log4jdemo.class);

    public static void main(String[] args) {
        System.out.println("\n Hello World.....!    \n");

        Logger.debug("This is a debug message");
        Logger.info("This is an info message");
        Logger.warn("This is a warning message");
        Logger.fatal("This is a fatal message");

        System.out.println("\n Completed");
    }

}
