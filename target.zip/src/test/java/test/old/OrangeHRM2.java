package test.old;

import org.testng.annotations.Test;

// calling extent report from TestNG
// calling page object page for google search page
//read the test data excel file
public class OrangeHRM2 {
    @Test(priority = 1)
    public void one(){
        System.out.println("I am inside Test 1");
    }
    @Test(priority = 1)
    public void two(){
        System.out.println("I am inside Test 2");
        //Assert.assertTrue(false);
    }
    @Test(priority = 1)
    public void three(){
        System.out.println("I am inside Test 3");
       // throw new SkipException("This test is skipped");
    }
}
