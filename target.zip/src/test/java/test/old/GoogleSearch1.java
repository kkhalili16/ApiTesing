package test.old;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GoogleSearch1 {
    public static void main(String[] args) {
        googleSearch();
    }

    public static void googleSearch(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.google.com");
        WebElement searchBox = driver.findElement(By.name("q"));
        searchBox.sendKeys("IBM");
        searchBox.sendKeys(Keys.RETURN);
        driver.close();
        driver.quit();
        System.out.println("Test Pass!!!");
    }
}
