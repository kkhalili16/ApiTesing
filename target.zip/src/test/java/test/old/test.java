package test.old;

import java.util.*;
/**
 * Create a function or method given an array of integers as input, that returns
 * a new array as follows:
 *
 * If array element = 0, store “bang” If array element is an even number, store
 * “fizz” All other numbers, store “buzz”
 *
 * Example input: [0 ,1 ,2 ,3 ] Example output: [“bang”,”buzz”,”fizz”,”buzz”]
 *
 *  -----------ENTER SOLUTION BELOW--------
 **/
public class test {
    public static void main(String[] args) throws Exception {
        // Your code here!
        int[] a = {0,1,2,3,4};
        String[] b = new String[5];

        for(int i=0;i<a.length;i++){

            if(a[i]%2!=0){

                b[i]="bang";

            }

            if(a[i]%2==0){

                b[i]="buzz";

            }

            if(a[i] ==0){

                b[i]="fizz";

            }

        }

        System.out.println(Arrays.toString(b));
    }
}
