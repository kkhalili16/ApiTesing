package test.old;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.GoogleSearchPage2;

// calling page object page for google search page

public class GoogleSearch4 {
    private static RemoteWebDriver driver = null;
    @BeforeTest
    public void setUpTest(){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
    }
    @Test
    public static void googleSearch(){
        //goto google.com
        driver.get("https://www.google.com");
        GoogleSearchPage2 searchPageObj = new GoogleSearchPage2(driver);
        searchPageObj.setTextInSearchBox("Automation step by step");
        searchPageObj.clickSearchButton();
    }
    @AfterTest
    public void tearDownTest(){
        //close browser
        driver.close();
        driver.quit();
        System.out.println("Test Pass!!!");
    }
}
