package test.old;

import com.BaseClass;
import com.BaseClassWebDriver;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.OrangeHRMLoginPage;

// calling extent report from TestNG
// calling page object page for google search page
//read the test data excel file
public class OrangeHRM3 extends BaseClassWebDriver {

    //setting up the test data file which will read the values from the Base class method testData()
    @DataProvider(name = "test1data")
    public Object[][] getData(){
        String excelPath =  projectPath+"/excel/data.xlsx";
        Object data[][] = testData(excelPath, "Sheet1");
        return data;
    }
    // the test data that was retrived in the getData method needs to be declared as variables in the test.
    @Test(dataProvider = "test1data")
    public void googleSearch(String username, String password, String search) throws Exception{
        //get the value from the excel sheet1 row 1 and column 2
        //String test1 = excel.getCellDataString(1,2);
        System.out.println("This is the search text1 xyz--------: " + search);
        // Test Case name and description
        ExtentTest test = extent.createTest("OrangeHRM Login", "Login to OrangeHRM web app");

        extent.setSystemInfo("Environment", Environment);
        extent.setSystemInfo("User Name", "Anwar A");

        try {
            test.log(Status.INFO, "Starting Test Case");
            //test.addScreenCaptureFromPath("screenshot.png");

            /*
            - Enter user name
            - Enter password
            - Click the LOGIN button
            */

            OrangeHRMLoginPage loginPageObj = new OrangeHRMLoginPage(driver);
            loginPageObj.setTextInUsernameBox(username);
            logger.info("Entered text " +username+ " in username textbox");
            test.pass("Entered text " +username+ " in username textbox");

            loginPageObj.setTextInPasswordBox(password);
            logger.info("Entered text " +password+ " in password textbox");
            test.pass("Entered text " +password+ " in password textbox");

            loginPageObj.clickLoginButton();
            logger.info("Pressed login button");
            test.pass("Pressed login button");

            loginPageObj.clickLoginButton();
            test.fail("details one").addScreenCaptureFromPath("screenshot.png");
        }
        catch (Exception exp){
            // reference image saved to disk
            test.fail("details one",
                    MediaEntityBuilder.createScreenCaptureFromPath("screenshot.jpg").build());
            test.fail("somthing went wrong =>"+ exp.getMessage());
        }
    }
}
