package test.old;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
// calling page object page for google search page
import pages.GoogleSearchPage;

public class GoogleSearch2 {
    private static WebDriver driver = null;

    public static void main(String[] args) {
        googleSearch();
    }

    public static void googleSearch(){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        //goto google.com
        driver.get("https://www.google.com");
        // \enter text in search textbox
        GoogleSearchPage.textbox_serach(driver).sendKeys("Automation setp by step");
        //click on search button
        GoogleSearchPage.sendKeys(Keys.RETURN);
        //close browser
        driver.close();
        driver.quit();
        System.out.println("Test Pass!!!");
    }
}
