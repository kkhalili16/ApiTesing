package test;

import com.BaseClassWebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.List;
// calling extent report from TestNG
// calling page object page for google search page
//read the test data excel file

public class NewTours extends BaseClassWebDriver {

    @DataProvider(name = "test1data")
    public Object[][] getData(){
        String excelPath =  projectPath+"/excel/data.xlsx";
        Object data[][] = testData(excelPath, "Sheet3");
        return data;
    }

    @Test(dataProvider = "test1data")
    public void newtours(String url) throws Exception {
        /* if you want to run it without testng xml file use the code below and remove Base class
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.get("http://www.tinyupload.com");
        */
        SoftAssert softAssert = new SoftAssert();
        test = extent.createTest("New Tour Website", "Displaying and verifying the main page");
        try {
            logger.info("Navigated to " + url);
            test.pass("Navigated to " + url);
            Thread.sleep(2000);

            Boolean verifyTitle = driver.getTitle().equalsIgnoreCase("Welcome: Mercury Tours");
            softAssert.assertNull(verifyTitle);
            softAssert.assertNotNull(verifyTitle);

            driver.navigate().to("http://demo.guru99.com/test/newtours/reservation.php");

            Thread.sleep(2000);
            //select departing from city
            Select selectByValue = new Select(driver.findElement(By.name("fromPort")));
            selectByValue.selectByValue("New York");
            Thread.sleep(2000);
            //select arriving in city
            Select selectByValueIn = new Select(driver.findElement(By.name("toPort")));
            selectByValueIn.selectByValue("London");
            Thread.sleep(2000);
            //select service class
            Select selectByVisibleText = new Select (driver.findElement(By.name("servClass")));
            selectByVisibleText.selectByVisibleText("Business");
            Thread.sleep(2000);

            // Storing the list
            List<WebElement> elementList = driver.findElements(By.xpath("//div[@id='example']//ul//li"));
            // Fetching the size of the list
            int listSize = elementList.size();
            for (int i=0; i<listSize; i++)
            {
            // Clicking on each service provider link
                //serviceProviderLinks.get(i).click();
            // Navigating back to the previous page that stores link to service providers
                driver.navigate().back();
            }

            //driver.findElement(By.xpath("//input[@type='filex']"));
        }catch (Exception exp){
            exp.getMessage();
            driver.close();
            driver.quit();
        }

        return ;
    }
}
